import React from 'react';
import MenuAfterLoginAdmin from '../MenuAfterLogin/MenuAfterLogin'
import './Firstpageafterlogin.css';

function Firstpageafterlogin() {
  return (
    <div>
      <MenuAfterLoginAdmin />
   
    </div>
  );
}

export default Firstpageafterlogin;
