import React from 'react';
import MenuAfterLogin from '../MenuAfterLogin/MenuAfterLogin';


function SupportPage() {
    return (
        <div>
            <MenuAfterLogin/>
            

        </div>
       
       
    );
}

export default SupportPage;
