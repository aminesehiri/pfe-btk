import React from 'react';
import MenuSimpleUser from '../MenuSimpleUseur/MenuSimpleUseur'

function FirstPageSimpleUser() {
  return (
    <div>
        <MenuSimpleUser/>
       
    </div>
  )
}

export default FirstPageSimpleUser


